﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

/// <summary>
/// UI页面元素占位符类，导出工具会自动导出带有此组件的UI对象到UI脚本
/// </summary>
public class WidgetID : MonoBehaviour
{
	public bool ignore;
}
